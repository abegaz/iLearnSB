package application;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class UserInfoController {
	@FXML Label FirstName, LastName, Email, Password;
	String user;

	public void setTextT(String use) throws SQLException{

			FirstName.setText(String.valueOf(use));
			this.user = (String.valueOf(use));

			Connection con = DBConnect.getConnection();

			String query = ("SELECT lastName, email, password FROM users WHERE firstName = '" + user +"'");
			Statement stmt = con.createStatement();

		        ResultSet rs = stmt.executeQuery(query);

		        while (rs.next()) {
		        	LastName.setText(rs.getString("lastName"));
		        	Email.setText(rs.getString("email"));
		        	Password.setText(rs.getString("password"));

		        }

	}

}
