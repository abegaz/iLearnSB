package application;

import java.awt.event.WindowEvent;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class HomePageController {
	@FXML Button User, Course1, Course2, Course3;
	@FXML Label NeedHelp, Course1O, Course2O, Course3O, TeachOne, TeachTwo, TeachThree;
	@FXML Tab tabOne, TabTwo, tabThree;
	String one, two, three, USER;

	public void setText(String use, String ONE, String TWO, String THREE) throws SQLException{
		this.User.setText("Welcome " + use);
		this.USER = (String.valueOf(use));
		tabOne.setText(String.valueOf(ONE));
		TabTwo.setText(String.valueOf(TWO));
		tabThree.setText(String.valueOf(THREE));

		Course1O.setText(String.valueOf(ONE));
		Course2O.setText(String.valueOf(TWO));
		Course3O.setText(String.valueOf(THREE));


		Connection con = DBConnect.getConnection();


		String query = ("SELECT teacher FROM course WHERE courseName = '" + ONE +"'");
		Statement stmt = con.createStatement();

	        ResultSet rs = stmt.executeQuery(query);

	        while (rs.next()) {
	           String first = rs.getString("teacher");
	           TeachOne.setText(String.valueOf(first));

	        }
        String queri = ("SELECT teacher FROM course WHERE courseName = '" + TWO +"'");
		Statement stamt = con.createStatement();

	        ResultSet rss = stamt.executeQuery(queri);

	        while (rss.next()) {
	           String second = rss.getString("teacher");
	           TeachTwo.setText(String.valueOf(second));

	        }

        String querie = ("SELECT teacher FROM course WHERE courseName = '" + THREE +"'");
		Statement staamt = con.createStatement();

	        ResultSet rsss = staamt.executeQuery(querie);

	        while (rsss.next()) {
	           String third = rsss.getString("teacher");
	           TeachThree.setText(String.valueOf(third));

	        }
	}

	/*
	public void setText(String ONE){
		we = ONE;
		Course1.setText(String.valueOf(ONE));


/*
		try{
		Connection con = DBConnect.getConnection();
				PreparedStatement statement = con.prepareStatement("SELECT CourseOne FROM users WHERE password = '" + we +"'");
				ResultSet reslut = statement.executeQuery();
				while(reslut.next())
				System.out.println(reslut.getString("CourseOne"));
				con.close();
		}catch(Exception e){
			e.printStackTrace();
		}

	}
*/
	public void signout(ActionEvent event) throws Exception{
		Stage primaryStage = new Stage();
		BorderPane root = (BorderPane)FXMLLoader.load(getClass().getResource("LoginMain.fxml"));
		Scene scene = new Scene(root,600,450);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		primaryStage.setScene(scene);
		primaryStage.show();
		((Node)event.getSource()).getScene().getWindow().hide();
	}

	public void user(ActionEvent event) throws Exception{

		String use = String.valueOf(USER);
		FXMLLoader Loader = new FXMLLoader();
		Loader.setLocation(getClass().getResource("UserInfo.fxml"));
		try {
			Loader.load();
		} catch (IOException ex){
			Logger.getLogger(HomePageController.class.getName()).log(Level.SEVERE, null, ex);
		}

		UserInfoController display = Loader.getController();
		display.setTextT(use);


try{
		Parent p = Loader.getRoot();
		Stage stage = new Stage();
		stage.setScene(new Scene(p));

		stage.showAndWait();
} catch(Exception e)
{
e.printStackTrace();
}

		/*
		Stage primaryStage = new Stage();
		AnchorPane root = (AnchorPane)FXMLLoader.load(getClass().getResource("UserInfo.fxml"));
		Scene scene = new Scene(root,600,450);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		primaryStage.setScene(scene);
		primaryStage.show();
*/

	}


	public void help2(){
		NeedHelp.setText("Call 777-777-7777 for customer support.");
	}






}

