package application;

import java.io.File;

import javafx.application.Application;
import javafx.application.HostServices;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.fxml.FXMLLoader;


public class Main extends Application {


	
	public enum HostServicesProvider {

	    INSTANCE ;

	    private HostServices hostServices ;
	    public void init(HostServices hostServices) {
	        if (this.hostServices != null) {
	            throw new IllegalStateException("Host services already initialized");
	        }
	        this.hostServices = hostServices ;
	    }
	    public HostServices getHostServices() {
	        if (hostServices == null) {
	            throw new IllegalStateException("Host services not initialized");
	        }
	        return hostServices ;
	    }
	}
	@Override
	public void start(Stage primaryStage) {
		
		HostServicesProvider.INSTANCE.init(getHostServices());
		try {
			
			 
			
			
			
			
			
			
			
			
			BorderPane root = (BorderPane)FXMLLoader.load(getClass().getResource("LoginMain.fxml"));
			Scene scene = new Scene(root,600,450);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		//DBConnect connect = new DBConnect();
		launch(args);

	}

	public void showDocument(String string) {
		// TODO Auto-generated method stub
		
	}
}
