package application;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
class MyException extends Exception{
	   String str1;
	   /* Constructor of custom exception class
	    * here I am copying the message that we are passing while
	    * throwing the exception to a string and then displaying 
	    * that string along with the message.
	    */
	   MyException() {
		
	   }
	   public String toString(){ 
		return ("MyException Occurred: "+str1) ;
	   }
	}
public class signupController {
	@FXML TextField firstNametxt,lastNametxt, emailtxt;
	@FXML PasswordField pass1,pass2;
    @FXML Button submitButton;
    @FXML Label submitMessage;
    
    	
    public void submitButtonPushed(ActionEvent event) throws Exception {
    	
    	
    	
    	
    	
    	try {
    		PreparedStatement ps;
    		int count=0;
    		ResultSet result;
    		Connection conn = DBConnect.getConnection();
    		ps=conn.prepareStatement("SELECT COUNT(*) FROM users ");
    		
    		result = ps.executeQuery();
    		if(result.next()){
			    count= result.getInt("COUNT(*)");
				
				
			}
    		
    		
    		
    		
    		ps = conn.prepareStatement("INSERT INTO `users`(id,`firstname`, `lastName`, `email`, `password`,courseOne,coursetwo,coursethree) VALUES (?,?,?,?,?,?,?,?)");
    		
    		if(firstNametxt.getText().trim().isEmpty()||lastNametxt.getText().trim().isEmpty()||emailtxt.getText().trim().isEmpty()||pass1.getText().trim().isEmpty()) {
    			/*firstNametxt.setText(null);
        	    lastNametxt.setText(null);
        	    emailtxt.setText(null);
        	    pass1.setText(null);
        	    pass2.setText(null);*/
    			throw new NullPointerException();
  
    		}
    		System.out.println(count+100);
    		ps.setInt(1, count+100);
    		ps.setString(2, firstNametxt.getText());
			ps.setString(3, lastNametxt.getText());
			ps.setString(4, emailtxt.getText());
			ps.setString(5, pass1.getText());
			ps.setString(6, "CSCI3000");
			ps.setString(7, "CSCI4500");
			ps.setString(8, "CSCI1301");
			
			if (pass2.getText().trim().isEmpty()==true) {
				throw new NullPointerException();
			}
			ps.executeUpdate();
			if(pass1.getText().toString().equals(pass2.getText().toString())==false){
			ps=conn.prepareStatement("SELECT COUNT(*) FROM users ");
		    result = ps.executeQuery();
			
			if(result.next()){
			    count= result.getInt("COUNT(*)");
				
				ps=conn.prepareStatement("DELETE FROM `users` WHERE id=?");
				System.out.println(count+99);
				ps.setInt(1, count+99);
				ps.execute();
				
			}
			throw new MyException();
			 
			}
    	    submitMessage.setText("Complete");
    	    firstNametxt.setText(null);
    	    lastNametxt.setText(null);
    	    emailtxt.setText(null);
    	    pass1.setText(null);
    	    pass2.setText(null);

    	}
    	catch(NullPointerException ex) {
    		submitMessage.setText("Submition fail\n"+"fields can not be empty");
    		firstNametxt.setText(null);
    	    lastNametxt.setText(null);
    	    emailtxt.setText(null);
    	    pass1.setText(null);
    	    pass2.setText(null);
    		 
    	}
    	catch(MyException ex) {
    		
    		submitMessage.setText("Passwords do not match\n"+"please enter the passwords again");
    		firstNametxt.setText(null);
    	    lastNametxt.setText(null);
    	    emailtxt.setText(null);
    	    pass1.setText(null);
    	    pass2.setText(null);
    	}
    		
    	
    	
    		
    	
    	
}
    
    
    
}
